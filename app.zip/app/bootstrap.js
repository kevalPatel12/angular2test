"use strict";
var browser_1 = require('angular2/platform/browser');
var todolist_1 = require('./todolist/todolist');
browser_1.bootstrap(todolist_1["default"]);
//# sourceMappingURL=bootstrap.js.map