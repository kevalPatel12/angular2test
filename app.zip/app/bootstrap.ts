import {bootstrap} from 'angular2/platform/browser';

import ToDoList from './todolist/todolist';


bootstrap(ToDoList);